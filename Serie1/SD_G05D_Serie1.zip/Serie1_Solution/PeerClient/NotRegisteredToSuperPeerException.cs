﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PeerClient
{
    public class NotRegisteredToSuperPeerException : Exception
    {
    }
}
