﻿using System;

namespace FormPeer
{
    public class NotRegisteredToSuperPeerException : Exception
    {
    }
}
