﻿using System;

namespace CommonInterface
{
    [Serializable]
    public struct Article
    {
        public string Title { get; set; }
        public string[] Authors { get; set; }
        public int PublishYear { get; set; }
        public string Summary { get; set; }
    }
}
