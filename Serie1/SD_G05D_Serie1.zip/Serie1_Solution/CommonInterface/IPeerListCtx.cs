﻿using System.Collections.Generic;

namespace CommonInterface
{
    public interface IPeerListCtx
    {
        bool CheckAndAdd(int sp);
    }
}